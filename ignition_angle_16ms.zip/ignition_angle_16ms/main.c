#include "stm8s.h"
#include "iostm8s105c6.h"
#include "stdbool.h"
//--------------------------------------------------------------------------------------------------------------//
uint32_t timer1_periodtime = 1999;
uint32_t timer2_periodtime;
uint32_t Temp_timer2_periodtime;
uint32_t timer3_periodtime;
uint32_t Temp_timer3_periodtime;
uint32_t T_ignition;

bool flag_UPDATE = 0;
bool flag_UPDATE_timer2_timerperiod = 0;
bool flag_UPDATE_timer3_timerperiod = 0;
bool flag_count_overflow;

uint16_t testvalue;
uint16_t testvalue1;
uint16_t testvalue2;
uint16_t testvalue3;
int count = 0;
uint32_t count_overflow = 0;
uint32_t temp_count_overflow = 0;
uint32_t T_end = 0;
uint32_t T_start = 0;
uint32_t T_oneround = 0;
//--------------------------------------------------------------------------------------------------------------//
void HSI_16MHz_config(void);
void GPIO_config(void);
void TIMER1_setup(void);
void TIMER2_setup(void);
void TIMER4_setup(void);
void TIMER3_setup(void);
void ADC2_setup(void);
uint16_t Read_ADC(int num_of_channel);
float map(float number1, float number2, float number3, float number4, float number5);
//--------------------------------------------------------------------------------------------------------------//
int main(void)
{
  HSI_16MHz_config();
  GPIO_config();
  ADC2_setup();
  T_ignition = (uint16_t)((float)map(Read_ADC(1), 0, 1023, 0, 45) / 360 * ((float)T_oneround / 256));
  //timer3_periodtime = (uint16_t)(map(Read_ADC(2), 0, 1023, 124, 1249));
  if (T_ignition + timer3_periodtime <= (uint16_t)(0.75 * (float)(T_oneround / 256)))
  {
    timer2_periodtime = (uint16_t)((float)T_oneround / 256) - T_ignition - timer3_periodtime;
  }
  else
  {
    timer2_periodtime = (uint16_t)(0.25 * (float)T_oneround / 256);
    timer3_periodtime = (uint16_t)(0.75 * (float)T_oneround / 256) - T_ignition;
  }
  Temp_timer3_periodtime = timer3_periodtime;
  Temp_timer2_periodtime = timer2_periodtime;
  TIMER1_setup();
  TIMER2_setup();
  TIMER3_setup();
  TIMER4_setup();

  while (1)
  {
    if (flag_UPDATE == 1)
    {
      T_ignition = (uint16_t)((float)map(Read_ADC(1), 0, 1023, 0, 45) / 360 * ((float)T_oneround / 256));
      //timer3_periodtime = (uint16_t)(map(Read_ADC(2), 0, 1023, 124, 1249));
      timer3_periodtime = 999; 
      if (T_ignition + timer3_periodtime <= (uint16_t)(0.75 * (float)(T_oneround / 256)))
      {
        timer2_periodtime = (uint16_t)((float)T_oneround / 256) - T_ignition - timer3_periodtime;
        flag_UPDATE_timer2_timerperiod = 1;
        flag_UPDATE_timer3_timerperiod = 1;
        flag_UPDATE = 0;
      }
      else
      {
        timer2_periodtime = (uint16_t)(0.25 * (float)T_oneround / 256);
        timer3_periodtime = (uint16_t)(0.75 * (float)T_oneround / 256) - T_ignition;
        flag_UPDATE_timer2_timerperiod = 1;
        flag_UPDATE_timer3_timerperiod = 1;
        flag_UPDATE = 0;
      }
    }
  }
}
// Timer1 - Input capture interrupt
//--------------------------------------------------------------------------------------------------------------//
INTERRUPT_HANDLER(TIM1_CAP_COM_IRQHandler, 12)
{
  if (TIM1_SR1_CC4IF == 1)
  {

    T_end = (uint16_t)((TIM1_CCR4H << 8) | (uint16_t)(TIM1_CCR4L));
    T_oneround = T_end - T_start + 2500 * count_overflow;
    count_overflow = 0;
    T_start = T_end;
    if (flag_UPDATE_timer2_timerperiod == 1)
    {
      Temp_timer2_periodtime = timer2_periodtime;
      flag_UPDATE_timer2_timerperiod = 0;
    }
    TIM2_ARRH = (Temp_timer2_periodtime >> 8);
    TIM2_ARRL = Temp_timer2_periodtime;
    TIM2_CR1_CEN = 1;
  }
  TIM1_SR1_CC4IF = 0; // Clear the interrupt flag
}
// Timer1 - Overflow interrupt
//--------------------------------------------------------------------------------------------------------------//
INTERRUPT_HANDLER(TIM1_UPD_OVF_TRG_BRK_IRQHandler, 11)
{
  count_overflow++;
  TIM1_SR1_UIF = 0; // Clear the interrupt flag
}
//--------------------------------------------------------------------------------------------------------------//
INTERRUPT_HANDLER(TIM2_UPD_OVF_BRK_IRQHandler, 13)
{
  PD_ODR_ODR0 = 1; // Set pin D0 at high level
  if (flag_UPDATE_timer3_timerperiod == 1)
  {
    Temp_timer3_periodtime = timer3_periodtime;
    flag_UPDATE_timer3_timerperiod = 0;
  }
  TIM3_ARRH = (Temp_timer3_periodtime >> 8);
  TIM3_ARRL = Temp_timer3_periodtime;
  TIM3_CR1_CEN = 1;//Enable TIMER3
  TIM2_CR1_CEN = 0;//Disable TIMER2
  TIM2_SR1_UIF = 0; // Clear the update interrupt flag of TIMER 2
}
//--------------------------------------------------------------------------------------------------------------//
INTERRUPT_HANDLER(TIM3_UPD_OVF_TRG_IRQHandler, 15)
{
  PD_ODR_ODR0 = 0; // Set pin D0 at low level
  TIM3_Cmd(DISABLE);
  TIM3_SR1_UIF = 0; // Clear the update interrupt flag of TIMER 3
}
//--------------------------------------------------------------------------------------------------------------//
INTERRUPT_HANDLER(TIM4_UPD_OVF_IRQHandler, 23)
{

  count++;
  if (count == 100)
  {
    flag_UPDATE = 1;
    count = 0;
  }
  TIM4_SR_UIF = 0 ;//Clear the update interrupt flag of TIMER4
}
//--------------------------------------------------------------------------------------------------------------//
INTERRUPT_HANDLER(EXTI_PORTB_IRQHandler, 4)
{
}
// Clock config
//--------------------------------------------------------------------------------------------------------------//
void HSI_16MHz_config(void)
{
  CLK_DeInit();
  CLK_HSICmd(ENABLE);
  CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
  CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1);
  CLK_ClockSwitchConfig(CLK_SWITCHMODE_AUTO, CLK_SOURCE_HSI, DISABLE, CLK_CURRENTCLOCKSTATE_DISABLE);

  CLK_PeripheralClockConfig(CLK_PERIPHERAL_SPI, DISABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_I2C, DISABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_AWU, DISABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_UART1, DISABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_UART3, DISABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER1, ENABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER2, ENABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER3, ENABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER4, ENABLE);
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_CAN, DISABLE);
}
// GPIO config
//--------------------------------------------------------------------------------------------------------------//
void GPIO_config(void)
{
  GPIO_DeInit(GPIOC);
  GPIO_Init(GPIOC, GPIO_PIN_4, GPIO_MODE_IN_PU_NO_IT);
  GPIO_DeInit(GPIOB);
  GPIO_Init(GPIOB, GPIO_PIN_1, GPIO_MODE_IN_FL_NO_IT);
  GPIO_Init(GPIOB, GPIO_PIN_2, GPIO_MODE_IN_FL_NO_IT);

  GPIO_DeInit(GPIOD);
  GPIO_Init(GPIOD, GPIO_PIN_0, GPIO_MODE_OUT_PP_HIGH_FAST);
  GPIO_Init(GPIOD, GPIO_PIN_2, GPIO_MODE_OUT_PP_HIGH_FAST);
}
// Timer 1 set up
//--------------------------------------------------------------------------------------------------------------//
void TIMER1_setup(void)
{
  TIM1_DeInit();
  TIM1_TimeBaseInit(0, TIM1_COUNTERMODE_UP, 2499, 0);
  TIM1_ICInit(TIM1_CHANNEL_4, TIM1_ICPOLARITY_RISING, TIM1_ICSELECTION_DIRECTTI, TIM1_ICPSC_DIV1, 1);
  TIM1_ARRPreloadConfig(ENABLE);
  TIM1_EGR_UG = 1;
  TIM1_ITConfig(TIM1_IT_UPDATE, ENABLE);
  TIM1_ITConfig(TIM1_IT_CC4, ENABLE);
  TIM1_Cmd(ENABLE);
  enableInterrupts();
}
// Timer2 set up
//--------------------------------------------------------------------------------------------------------------//
void TIMER2_setup(void)
{
  TIM2_DeInit();
  TIM2_TimeBaseInit(TIM2_PRESCALER_256, timer2_periodtime);
  TIM2_ARRPreloadConfig(DISABLE);
  TIM2_ITConfig(TIM2_IT_UPDATE, ENABLE);
  enableInterrupts();
}
// Timer 3 set up
//--------------------------------------------------------------------------------------------------------------//
void TIMER3_setup(void)
{
  TIM3_DeInit();
  TIM3_TimeBaseInit(TIM3_PRESCALER_256, timer3_periodtime);
  TIM3_ARRPreloadConfig(DISABLE);
  TIM3_ITConfig(TIM3_IT_UPDATE, ENABLE);
  enableInterrupts();
}
// Timer 4 set up
//--------------------------------------------------------------------------------------------------------------//
void TIMER4_setup(void)
{
  TIM4_DeInit();
  TIM4_TimeBaseInit(TIM4_PRESCALER_64, 249);
  TIM4_ARRPreloadConfig(DISABLE);
  TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
  TIM4_Cmd(ENABLE);
  enableInterrupts();
}
// ADC2 set up
//--------------------------------------------------------------------------------------------------------------//
void ADC2_setup(void)
{
  // Right alignment
  ADC_CR2_ALIGN = 1;
  // Enable ADC2 and start conversion
  ADC_CR1_ADON = 1;
}
// Read ADC
//--------------------------------------------------------------------------------------------------------------//
uint16_t Read_ADC(int num_of_channel)
{
  uint16_t value_of_ADC_conversion;
  // Choose channel for conversion
  ADC_CSR_CH = num_of_channel;
  // Enable ADC1 and start conversion
  ADC_CR1_ADON = 1;
  // Wait for the conversion complete
  while (ADC_CSR_EOC == 0)
    ;
  // Clear the conversion complete bit
  ADC_CSR_EOC = 0;
  // get the value of ADC conversion
  value_of_ADC_conversion = ADC_DRL;
  value_of_ADC_conversion |= (ADC_DRH << 8);

  return value_of_ADC_conversion;
}
// Map function
//--------------------------------------------------------------------------------------------------------------//
float map(float number1, float number2, float number3, float number4, float number5)
{
  return (number5 - ((number3 - number1) / (number3 - number2)) * (number5 - number4));
}
